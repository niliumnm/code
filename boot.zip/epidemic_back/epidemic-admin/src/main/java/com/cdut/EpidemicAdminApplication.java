package com.cdut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpidemicAdminApplication {

    public static void main(String[] args) {
        SpringApplication.run(EpidemicAdminApplication.class, args);
    }

}
