### 1. epidemic-admin
提供用户接口以及后台管理接口，统合其他模块
### 2. epidemic-framework
业务需求的编写，封装功能
### 3. epidemic-system
数据库crud，以及对应的service封装
### 4. epidemic-common
提供封装工具类
