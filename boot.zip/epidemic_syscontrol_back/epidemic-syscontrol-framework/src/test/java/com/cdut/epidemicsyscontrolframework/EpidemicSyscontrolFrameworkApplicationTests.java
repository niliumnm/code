package com.cdut.epidemicsyscontrolframework;

import com.cdut.epidemicsyscontrolframework.services.SysLoginService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpidemicSyscontrolFrameworkApplicationTests {


    @Test
    void contextLoads() {
    }

}
