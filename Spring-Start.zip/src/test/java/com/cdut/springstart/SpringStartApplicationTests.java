package com.cdut.springstart;

import com.cdut.springstart.controller.UserController;
import com.cdut.springstart.pojo.User;
import com.cdut.springstart.pojo.book;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringStartApplicationTests {

    @Test
    public void test() {
        ApplicationContext ioc = new AnnotationConfigApplicationContext("com.cdut.springstart");
        UserController userController = ioc.getBean("UserController", UserController.class);
        userController.update(new book(1, "111", "好的"));

    }

}
