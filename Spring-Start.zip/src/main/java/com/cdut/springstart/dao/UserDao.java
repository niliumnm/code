package com.cdut.springstart.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.cdut.springstart.pojo.book;
import org.springframework.stereotype.Repository;


@Repository
public class UserDao {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public int insert(book book) {
        String sql = "insert into t_book values(?,?,?)";
        Object args[] = {book.getBook_id(), book.getName(), book.getStatus()};
        return jdbcTemplate.update(sql, args);
    }

    public int update(book book) {
        String sql = "update t_book set status=?,name=? where book_id=?";
        Object args[] = { book.getName(), book.getStatus(),book.getBook_id()};
        return jdbcTemplate.update(sql, args);
    }
    public int delete(int id) {
        String sql = "delete from t_book where book_id=?";
        Object args[] = {id};
        return jdbcTemplate.update(sql, args);
    }

}

