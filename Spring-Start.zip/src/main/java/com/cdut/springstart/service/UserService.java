package com.cdut.springstart.service;

import com.cdut.springstart.dao.UserDao;
import com.cdut.springstart.pojo.book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    UserDao userDao;

    public int update(book book) {
        return userDao.update(book);
    }

}
