package com.cdut.springstart;
import com.cdut.springstart.controller.UserController;
import com.cdut.springstart.dao.UserDao;
import com.cdut.springstart.pojo.book;
import org.junit.Test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {

    @Test
    public static void main(String[] args) {
        BeanFactory ioc = new ClassPathXmlApplicationContext("spring-config.xml");
        UserController userController = ioc.getBean("userController", UserController.class);
        UserDao userDao = ioc.getBean("userDao", UserDao.class);
        userDao.delete(2);


    }

}
