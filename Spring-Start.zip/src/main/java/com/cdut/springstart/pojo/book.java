package com.cdut.springstart.pojo;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class book {
    private Integer book_id;
    private String name;
    private String status;

    public book() {
    }

    public book(Integer book_id, String name, String status) {
        this.book_id = book_id;
        this.name = name;
        this.status = status;
    }

    public Integer getBook_id() {
        return book_id;
    }

    public void setBook_id(Integer book_id) {
        this.book_id = book_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
