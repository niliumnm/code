package com.cdut.springstart.pojo;

public class UserFactory {
    private static User user;
    public static User getUser() {
        if(user==null){
            user = new User();
        }
        return user;
    }
}
