package com.cdut.springstart.pojo;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class User {
    public void say() {
        System.out.println("创建成功");

    }
}
