package com.cdut.springstart.controller;

import com.cdut.springstart.pojo.book;
import com.cdut.springstart.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class UserController {
    @Autowired
    UserService userService;
    public int update(book book ){
        return userService.update(book);
    }

}
